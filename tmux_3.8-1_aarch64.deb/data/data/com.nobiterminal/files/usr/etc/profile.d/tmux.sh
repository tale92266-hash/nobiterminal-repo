export TMUX_TMPDIR=/data/data/com.nobiterminal/files/usr/var/run
