/*
* Certificate Store
* (C) 1999-2010,2013 Jack Lloyd
*
* Botan is released under the Simplified BSD License (see license.txt)
*/

#ifndef BOTAN_CERT_STORE_H_
#define BOTAN_CERT_STORE_H_

#include <botan/pkix_types.h>
#include <botan/x509_crl.h>
#include <botan/x509cert.h>
#include <memory>
#include <optional>
#include <vector>

namespace Botan {

/**
* Certificate Store Interface
*/
class BOTAN_PUBLIC_API(2, 0) Certificate_Store /* NOLINT(*-special-member-functions) */ {
   public:
      virtual ~Certificate_Store();

      /**
      * Find a certificate by Subject DN and (optionally) key identifier
      * @param subject_dn the subject's distinguished name
      * @param key_id an optional key id
      * @return a matching certificate or nullopt otherwise
      * If more than one certificate in the certificate store matches, then
      * a single value is selected arbitrarily.
      */
      virtual std::optional<X509_Certificate> find_cert(const X509_DN& subject_dn,
                                                        const std::vector<uint8_t>& key_id) const;

      /**
      * Find all certificates with a given Subject DN.
      * Subject DN and even the key identifier might not be unique.
      */
      virtual std::vector<X509_Certificate> find_all_certs(const X509_DN& subject_dn,
                                                           const std::vector<uint8_t>& key_id) const = 0;

      /**
      * Find a certificate by searching for one with a matching SHA-1 hash of
      * public key. Used for OCSP.
      * @param key_hash SHA-1 hash of the subject's public key
      * @return a matching certificate or nullopt otherwise
      */
      virtual std::optional<X509_Certificate> find_cert_by_pubkey_sha1(const std::vector<uint8_t>& key_hash) const = 0;

      /**
      * Find a certificate by searching for one with a matching SHA-256 hash of
      * raw subject name. Used for OCSP.
      * @param subject_hash SHA-256 hash of the subject's raw name
      * @return a matching certificate or nullopt otherwise
      */
      virtual std::optional<X509_Certificate> find_cert_by_raw_subject_dn_sha256(
         const std::vector<uint8_t>& subject_hash) const = 0;

      /**
      * Find a certificate by searching for one with a matching issuer DN and
      * serial number. Used for CMS or PKCS#7.
      * @param issuer_dn the distinguished name of the issuer
      * @param serial_number the certificate's serial number
      * @return a matching certificate or nullopt otherwise
      *
      * TODO(Botan4) change this to use X509_Serial_Number
      */
      virtual std::optional<X509_Certificate> find_cert_by_issuer_dn_and_serial_number(
         const X509_DN& issuer_dn, std::span<const uint8_t> serial_number) const = 0;

      /**
      * Finds a CRL for the given certificate
      * @param subject the subject certificate
      * @return the CRL for subject or nullopt otherwise
      */
      virtual std::optional<X509_CRL> find_crl_for(const X509_Certificate& subject) const;

      /**
      * @return whether this certificate is contained within the store
      * @param cert certificate to be searched
      *
      * Default implementation uses find_all_certs
      */
      virtual bool contains(const X509_Certificate& cert) const;

      /**
      * Old version of contains
      */
      bool certificate_known(const X509_Certificate& cert) const;

      // remove this (used by TLS::Server)
      virtual std::vector<X509_DN> all_subjects() const = 0;
};

/**
* In Memory Certificate Store
*/
class BOTAN_PUBLIC_API(2, 0) Certificate_Store_In_Memory final : public Certificate_Store {
   public:
#if defined(BOTAN_TARGET_OS_HAS_FILESYSTEM)
      /**
      * Attempt to parse all files in dir (including subdirectories)
      * as certificates. Ignores errors.
      */
      explicit Certificate_Store_In_Memory(std::string_view dir);
#endif

      /**
      * Adds given certificate to the store.
      */
      explicit Certificate_Store_In_Memory(const X509_Certificate& cert);

      /**
      * Adds given certificate and CRL to the store.
      */
      Certificate_Store_In_Memory(const X509_Certificate& cert, const X509_CRL& crl);

      /**
      * Create an empty store.
      */
      Certificate_Store_In_Memory();

      Certificate_Store_In_Memory(const Certificate_Store_In_Memory& other);
      Certificate_Store_In_Memory(Certificate_Store_In_Memory&& other) noexcept;

      Certificate_Store_In_Memory& operator=(const Certificate_Store_In_Memory& other) = delete;
      Certificate_Store_In_Memory& operator=(Certificate_Store_In_Memory&& other) noexcept;

      ~Certificate_Store_In_Memory() override;

      /**
      * Add a certificate to the store.
      * @param cert certificate to be added
      */
      void add_certificate(const X509_Certificate& cert);

      /**
      * Add a certificate revocation list (CRL) to the store.
      * @param crl CRL to be added
      */
      void add_crl(const X509_CRL& crl);

      /**
      * @return DNs for all certificates managed by the store
      */
      std::vector<X509_DN> all_subjects() const override;

      /*
      * Find a certificate by Subject DN and (optionally) key identifier
      * @return the first certificate that matches
      */
      std::optional<X509_Certificate> find_cert(const X509_DN& subject_dn,
                                                const std::vector<uint8_t>& key_id) const override;

      /*
      * Find all certificates with a given Subject DN.
      * Subject DN and even the key identifier might not be unique.
      */
      std::vector<X509_Certificate> find_all_certs(const X509_DN& subject_dn,
                                                   const std::vector<uint8_t>& key_id) const override;

      std::optional<X509_Certificate> find_cert_by_pubkey_sha1(const std::vector<uint8_t>& key_hash) const override;

      std::optional<X509_Certificate> find_cert_by_raw_subject_dn_sha256(
         const std::vector<uint8_t>& subject_hash) const override;

      std::optional<X509_Certificate> find_cert_by_issuer_dn_and_serial_number(
         const X509_DN& issuer_dn, std::span<const uint8_t> serial_number) const override;

      /**
      * Finds a CRL for the given certificate
      */
      std::optional<X509_CRL> find_crl_for(const X509_Certificate& subject) const override;

      bool contains(const X509_Certificate& cert) const override;

   private:
      class Impl;

      Impl& impl();
      const Impl& impl() const;

      std::unique_ptr<Impl> m_impl;
};

}  // namespace Botan

#endif
