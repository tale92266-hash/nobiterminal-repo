set(RESOLV_WRAPPER_LIBRARY /data/data/com.nobiterminal/files/usr/lib/libresolv_wrapper.so)
